#include "Sphere.h"
#include <iostream>
#include <GL/glut.h>
#include <vector>
#include <windows.h> 

using namespace std;

#define WINDOW_WIDTH 1920      // window's width
#define WINDOW_HEIGHT 1080      // window's height

Sphere::Sphere() { launchtrue = false; isbomb = false; on_the_sphere = true; }
Sphere::Sphere(float r, int sl, int st) {
    radius = r; slice = sl; stack = st; launchtrue = false; isbomb = false; on_the_sphere = true;
}
void Sphere::setRadius(float r) {
    radius = r;
}
float Sphere::getRadius() const {
    return radius;
}
void Sphere::setSlice(int sl) {
    slice = sl;
}
void Sphere::setStack(int st) {
    stack = st;
}
void Sphere::setCenter(float x, float y, float z) {
    center[0] = x; center[1] = y; center[2] = z;
}
const float* Sphere::getCenter() const {
    return center;
}
void Sphere::setVelocity(float x, float y, float z) {
    velocity[0] = x; velocity[1] = y; velocity[2] = z;
}
const float* Sphere::getVelocity() const {
    return velocity;
}
void Sphere::setMTL(const Material& m) {
    mtl = m;
}

const string Sphere::getColor() const {
    if (mtl.getAmbient()[0] == 1.f)
        return "red";
    else if (mtl.getAmbient()[1] == 1.f)
        return "green";
    if (mtl.getAmbient()[2] == 1.f)
        return "blue";
}

void Sphere::move() {
}
void Sphere::setisbomb(bool a)
{
    isbomb = a;
}
bool Sphere::getbomb() { return isbomb; }
void Sphere::moveLine(int i)
{
    if (isbomb == false)
    {
        center[0] = map.ptr_x[i];
        center[1] = map.ptr_y[i];
    }
}
void Sphere::moveLine2(int i)
{
    if (isbomb == false)
    {
        center[0] = map2.ptr_x[i];
        center[1] = map2.ptr_y[i];
    }
}
bool Sphere::getLaunchtrue() {
    return launchtrue;
}
void Sphere::launch() {

    launchtrue = true;
    center[0] += velocity[0];
    center[1] += velocity[1];
}

void Sphere::makeSphere() {
    Material mmtl;

    mmtl.setEmission(0.1f, 0.1f, 0.1f, 1.0f);
    mmtl.setDiffuse(0.7f, 0.7f, 0.7f, 1.0f);
    mmtl.setSpecular(1.0f, 1.0f, 1.0f, 1.0f);
    mmtl.setShininess(10.0f);
    srand((unsigned int)time(NULL) + rand());
    int randColorIdx = rand() % 3 + 1;
    vector<float> v;

    if (randColorIdx == 1)
        v = { 1.f, 0.f, 0.f, 1.f };
    else if (randColorIdx == 2)
        v = { 0.f, 1.f, 0.f, 1.f };
    else if (randColorIdx == 3)
        v = { 0.f, 0.f, 1.f, 1.f };

    mmtl.setAmbient(v[0], v[1], v[2], v[3]);

    radius = 40, slice = 20, stack = 20;
    setCenter(-160.f, 0.f, 0.f);
    setMTL(mmtl);
}

void Sphere::draw() const {
    glShadeModel(GL_SMOOTH);
    glMaterialfv(GL_FRONT, GL_EMISSION, mtl.getEmission());
    glMaterialfv(GL_FRONT, GL_AMBIENT, mtl.getAmbient());
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mtl.getDiffuse());
    glMaterialfv(GL_FRONT, GL_SPECULAR, mtl.getSpecular());
    glMaterialfv(GL_FRONT, GL_SHININESS, mtl.getShininess());

    glPushMatrix();
    glTranslatef(center[0], center[1], center[2]);
    glutSolidSphere(radius, slice, stack);
    glPopMatrix();
}

void Sphere::CanonDraw() const {
    glShadeModel(GL_SMOOTH);
    glMaterialfv(GL_FRONT, GL_EMISSION, mtl.getEmission());
    glMaterialfv(GL_FRONT, GL_AMBIENT, mtl.getAmbient());
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mtl.getDiffuse());
    glMaterialfv(GL_FRONT, GL_SPECULAR, mtl.getSpecular());
    glMaterialfv(GL_FRONT, GL_SHININESS, mtl.getShininess());

    glutWireSphere(radius, slice, stack);
}

bool Sphere::get_on_the_sphere() const
{
    return on_the_sphere;
}
void Sphere::set_on_the_sphere(bool a)
{
    on_the_sphere = a;
}