#include <iostream>
#include <vector>
#include <GL/glut.h>
#include "Bezier.h"

using namespace std;

///////////////// 1���� ������ Ŀ�� ���� ������ t���� point���ϱ�
double Bezier::decas(vector<double>& coeff, double t)
{
    int r, i;
    double t1;
    double coeffa[30];
    t1 = 1.0 - t;
    for (i = 0; i <= 5; i++)
    {
        coeffa[i] = coeff[i]; // save input
    }
    for (r = 1; r <= 5; r++)
    {
        for (i = 0; i <= 5 - r; i++)
        {
            coeffa[i] = t1 * coeffa[i] + t * coeffa[i + 1];
        }
    }
    return (coeffa[0]);
}

///////////////// 1���� ������ Ŀ�� ���� x���� 10�� �迭�� �����
vector<double> Bezier::hundred_points(vector<double>& bez_control_point)
{
    vector<double> x; //number of data = density + 1

    for (int i = 0; i < 10000; i++)
    {
        double t;
        t = double(i) / 9999;

        x.push_back(decas(bez_control_point, t));

    }
    for (int i = 0; i < 10000; i++)
    {
        double t;
        t = double(i) / 9999;

        x.push_back(decas(bez_control_point, t));

    }
    return x;
}

void Bezier::makemap(vector<vector<double>>& controlpoint)
{
    vector<double> controlpoint_x;
    vector<double> controlpoint_y;
    for (int i = 0; i < controlpoint.size(); i++)
    {
        controlpoint_x.push_back(controlpoint[i][0]);
        controlpoint_y.push_back(controlpoint[i][1]);
    }

    ptr_x = hundred_points(controlpoint_x);
    ptr_y = hundred_points(controlpoint_y);
}

void Bezier::drawmap(vector<double> _ptr_x, vector<double> _ptr_y)
{
    glLineWidth(5.f);
    glColor3f(0.7, 0.7, 0.7);
    glBegin(GL_LINE_STRIP);

    for (int i = 0; i < 10000; i++)
    {
        glVertex3d(_ptr_x[i], _ptr_y[i], 0);
    }
    glEnd();
}