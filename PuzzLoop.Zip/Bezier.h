#pragma once

#include <vector>
#include <iostream>

using namespace std;

class Bezier
{
public:
	double decas(vector<double>& coeff, double t);
	vector<double> hundred_points(vector<double>& bez_control_point);
	void makemap(vector<vector<double>>& controlpoint);
	void drawmap(vector<double> _ptr_x, vector<double> _ptr_y);

	vector<double> ptr_x;
	vector<double> ptr_y;
};