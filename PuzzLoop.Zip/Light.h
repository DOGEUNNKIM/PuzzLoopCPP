#pragma once

class Light {
public:
	Light(int x, int y, int z, int id);
	void setAmbient(float r, float g, float b, float a);
	void setDiffuse(float r, float g, float b, float a);
	void setSpecular(float r, float g, float b, float a);
	void draw() const;

private:
	int lightID;
	float pos[3];
	float ambient[4];
	float diffuse[4];
	float specular[4];
};
