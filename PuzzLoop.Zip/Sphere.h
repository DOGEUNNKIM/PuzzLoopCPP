#pragma once
#include "Material.h"
#include "Bezier.h"

extern Bezier map;
extern Bezier map2;
extern double movelen;

class Sphere {
public:
	Sphere();
	Sphere(float r, int sl, int st);
	void setRadius(float r);
	float getRadius() const;
	void setSlice(int sl);
	void setStack(int st);
	void setCenter(float x, float y, float z);
	const float* getCenter() const;
	void setVelocity(float x, float y, float z);
	const float* getVelocity() const;
	void setMTL(const Material& m);
	const string getColor() const;
	void move();
	void moveLine(int i);
	void moveLine2(int i);
	bool getLaunchtrue();
	void launch();
	void makeSphere();
	void draw() const;
	void setisbomb(bool a);
	bool getbomb();
	void CanonDraw() const;
	bool get_on_the_sphere() const;
	void set_on_the_sphere(bool a);

private:
	bool isbomb;
	float radius;
	int slice;
	int stack;
	float center[3];
	float velocity[3];
	Material mtl;
	bool launchtrue;
	bool on_the_sphere;
};

extern vector<Sphere> Linespheres;
extern vector<Sphere> Linespheres1;
extern vector<Sphere> Linespheres2;