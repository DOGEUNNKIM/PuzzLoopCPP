#include <iostream>
#include <vector>
#include "Sphere.h"
#include "Light.h"
#include "Texture.h"
#include "Bezier.h"
#include <cmath>

using namespace std;

#define WINDOW_X 0
#define WINDOW_Y 0

#define WINDOW_WIDTH 1920      // window's width
#define WINDOW_HEIGHT 1080      // window's height

#define boundaryX (WINDOW_WIDTH)/2
#define boundaryY (WINDOW_HEIGHT)/2

int time_for_keyboard = 0;
int time_for_keyboard1 = 0;
int time_for_keyboard2 = 0;
int second_crush = 0;
int second_crush1 = 0;
int second_crush2 = 0;

int happen_second_crush = 0;
int happen_second_crush1 = 0;
int happen_second_crush2 = 0;
clock_t start_t = clock();
clock_t end_t;
vector<vector<double>> controlpoint = {
    {-boundaryX,-boundaryY},
     {-boundaryX , 0},
    {-boundaryX + 300 , boundaryY},
    {boundaryX * 2 / 3 - 300 ,boundaryY},
    {boundaryX * 2 / 3, 0} ,
    {boundaryX * 2 / 3, -boundaryY} };
vector<vector<double>> controlpoint1 = { {boundaryX * 2 / 3,boundaryY},{boundaryX * 2 / 3 , 0}, {boundaryX * 2 / 3 - 300 , -boundaryY},{-boundaryX + 300 ,-boundaryY},{-boundaryX , 0} ,{-boundaryX, boundaryY} };

vector<Sphere> spheres;
vector<Sphere> Linespheres;
vector<Sphere> Linespheres1;
vector<Sphere> Linespheres2;
Sphere Canon(120, 8, 8);
Sphere tempSphere;

Light light(boundaryX, boundaryY, boundaryX / 2, GL_LIGHT0);
Texture texture;
Texture GameStart;
Texture GameOver;
Texture StageClear;
Texture Img;
Bezier map;
Bezier map1;
Bezier map2;

int stage_idx = 0;

extern double movelen = 0;
extern double movelen1 = 0;
extern double movelen2 = 0;
double move_ = 0;
double move_1 = 0;
double move_2 = 0;
float Angle = 0.5 * 3.14159265f;
float AngVel = 0.08f;

void LineMoveSphere()
{
    Material mtl;
    mtl.setEmission(0.1f, 0.1f, 0.1f, 1.0f);
    mtl.setAmbient(0.f, 0.f, 1.f, 1.0f);
    mtl.setDiffuse(0.7f, 0.7f, 0.7f, 1.0f);
    mtl.setSpecular(1.0f, 1.0f, 1.0f, 1.0f);
    mtl.setShininess(10.0f);

    Material mtl2(mtl), mtl3(mtl);
    mtl2.setAmbient(1.0f, 0.f, 0.f, 1.0f);
    mtl3.setAmbient(0.f, 1.f, 0.f, 1.0f);

    for (int i = 0; i < 10; i++)
    {
        Sphere ball(40, 20, 20);

        ball.makeSphere();
        ball.setCenter(map.ptr_x[0], map.ptr_y[0], 0.0f);
        Linespheres.insert(Linespheres.begin(), ball);

        Sphere ball1(40, 20, 20);
        ball1.makeSphere();
        ball1.setCenter(map1.ptr_x[0], map1.ptr_y[0], 0.0f);
        Linespheres1.insert(Linespheres1.begin(), ball1);

        Sphere ball2(40, 20, 20);
        ball2.makeSphere();
        ball2.setCenter(map2.ptr_x[0], map2.ptr_y[0], 0.0f);
        Linespheres2.insert(Linespheres2.begin(), ball2);
    }
}

void initialize() {
    light.setAmbient(0.3f, 0.3f, 0.3f, 1.0f);
    light.setDiffuse(0.4f, 0.4f, 0.4f, 1.0f);
    light.setSpecular(0.5f, 0.5f, 0.5f, 1.0f);

    Material mtl0;
    mtl0.setEmission(0.1f, 0.1f, 0.1f, 1.0f);
    mtl0.setAmbient(0.f, 0.f, 1.f, 1.0f);
    mtl0.setDiffuse(0.7f, 0.7f, 0.7f, 1.0f);
    mtl0.setSpecular(1.0f, 1.0f, 1.0f, 1.0f);
    mtl0.setShininess(10.0f);

    Material mtl1(mtl0);
    mtl1.setAmbient(1.0f, 0.f, 0.f, 1.0f);

    Material mtl2(mtl0);
    mtl2.setAmbient(0.3f, 0.3f, 0.3f, 1.0f);

    Sphere sphere0(40, 20, 20);
    sphere0.setCenter(80 * cos(Angle) - 160.f, 80 * sin(Angle), 0.0f);
    sphere0.setMTL(mtl0);
    sphere0.setVelocity(4 * cos(Angle), 4 * sin(Angle), 0.0f);
    sphere0.set_on_the_sphere(false);
    spheres.push_back(sphere0);

    Sphere sphere1(sphere0);
    sphere1.setCenter(-160.f, 0.f, 0.0f);
    sphere1.setMTL(mtl1);
    sphere1.setVelocity(4 * cos(Angle), 4 * sin(Angle), 0.0f);
    sphere1.set_on_the_sphere(false);
    spheres.push_back(sphere1);

    Canon.setCenter(-160.f, 0.f, -80.f);
    Canon.setMTL(mtl2);

    /* Implement: initialize texture */
    FIBITMAP* bitmap32 = texture.createBitMap("keyboard.png");
    texture.imageWidth = FreeImage_GetWidth(bitmap32);
    texture.imageHeight = FreeImage_GetHeight(bitmap32);
    texture.textureData = FreeImage_GetBits(bitmap32);
    texture.generateTexture();

    FIBITMAP* bitmap1 = GameStart.createBitMap("GameStart.png");
    GameStart.imageWidth = FreeImage_GetWidth(bitmap1);
    GameStart.imageHeight = FreeImage_GetHeight(bitmap1);
    GameStart.textureData = FreeImage_GetBits(bitmap1);
    GameStart.generateTexture();

    FIBITMAP* bitmap2 = GameOver.createBitMap("GameOver.png");
    GameOver.imageWidth = FreeImage_GetWidth(bitmap2);
    GameOver.imageHeight = FreeImage_GetHeight(bitmap2);
    GameOver.textureData = FreeImage_GetBits(bitmap2);
    GameOver.generateTexture();

    FIBITMAP* bitmap3 = StageClear.createBitMap("StageClear.png");
    StageClear.imageWidth = FreeImage_GetWidth(bitmap3);
    StageClear.imageHeight = FreeImage_GetHeight(bitmap3);
    StageClear.textureData = FreeImage_GetBits(bitmap3);
    StageClear.generateTexture();

    FIBITMAP* bitmap4 = Img.createBitMap("img.png");
    Img.imageWidth = FreeImage_GetWidth(bitmap4);
    Img.imageHeight = FreeImage_GetHeight(bitmap4);
    Img.textureData = FreeImage_GetBits(bitmap4);
    Img.generateTexture();

    map.makemap(controlpoint);
    map1.makemap(controlpoint);
    map2.makemap(controlpoint1);

    LineMoveSphere();
}

float DistanceSphere(const Sphere& sph1, const Sphere& sph2) {
    return pow(pow(sph1.getCenter()[0] - sph2.getCenter()[0], 2) + pow(sph1.getCenter()[1] - sph2.getCenter()[1], 2), 0.5);
}

bool isCollisionDetected(const Sphere& sph1, const Sphere& sph2) {
    if (DistanceSphere(sph1, sph2) <= sph1.getRadius() + sph2.getRadius())
        return true;
    else return false;
}
bool isSameDetected_2(const Sphere& sph1, const Sphere& sph2) {
    if (sph1.getColor() == sph2.getColor())
        return true;
    else return false;
}
bool isSameDetected(const Sphere& sph1, const Sphere& sph2, const Sphere& sph3) {
    if (sph1.getColor() == sph2.getColor() && sph2.getColor() == sph3.getColor())
        return true;
    else return false;
}
bool isSameDetected_4(const Sphere& sph1, const Sphere& sph2, const Sphere& sph3, const Sphere& sph4) {
    if (sph1.getColor() == sph2.getColor() && sph2.getColor() == sph3.getColor() && sph3.getColor() == sph4.getColor())
        return true;
    else return false;
}
bool isSameDetected_5(const Sphere& sph1, const Sphere& sph2, const Sphere& sph3, const Sphere& sph4, const Sphere& sph5) {
    if (sph1.getColor() == sph2.getColor() && sph2.getColor() == sph3.getColor() && sph3.getColor() == sph4.getColor() && sph4.getColor() == sph5.getColor())
        return true;
    else return false;
}
bool isSameDetected_6(const Sphere& sph1, const Sphere& sph2, const Sphere& sph3, const Sphere& sph4, const Sphere& sph5, const Sphere& sph6) {
    if (sph1.getColor() == sph2.getColor() && sph2.getColor() == sph3.getColor() && sph3.getColor() == sph4.getColor() && sph4.getColor() == sph5.getColor() && sph5.getColor() == sph6.getColor())
        return true;
    else return false;
}
bool isSameDetected_7(const Sphere& sph1, const Sphere& sph2, const Sphere& sph3, const Sphere& sph4, const Sphere& sph5, const Sphere& sph6, const Sphere& sph7) {
    if (sph1.getColor() == sph2.getColor() && sph2.getColor() == sph3.getColor() && sph3.getColor() == sph4.getColor() && sph4.getColor() == sph5.getColor() && sph5.getColor() == sph6.getColor() && sph6.getColor() == sph7.getColor())
        return true;
    else return false;
}
bool isSameDetected_8(const Sphere& sph1, const Sphere& sph2, const Sphere& sph3, const Sphere& sph4, const Sphere& sph5, const Sphere& sph6, const Sphere& sph7, const Sphere& sph8) {
    if (sph1.getColor() == sph2.getColor() && sph2.getColor() == sph3.getColor() && sph3.getColor() == sph4.getColor() && sph4.getColor() == sph5.getColor() && sph5.getColor() == sph6.getColor() && sph6.getColor() == sph7.getColor() && sph7.getColor() == sph8.getColor())
        return true;
    else return false;
}
void idle()
{
    end_t = clock();

    static int inside_bomb = 0;
    static int inside_bomb1 = 0;
    static int inside_bomb2 = 0;
    static int zerobomb = 0;
    static int zerobomb1 = 0;
    static int zerobomb2 = 0;


    static float time = 0;
    static float time1 = 0;
    static float time2 = 0;
    static vector<int> delta_time;
    static vector<int> delta_time1;
    static vector<int> delta_time2;



    /////////////////////////////////////////////////////stage1///////////////////////////////////////////////
    if (stage_idx == 1) {

        if (Linespheres.size() != 0)
        {
            /////////////////////////////////�浹 ����
            if (time_for_keyboard > 1000 && Linespheres.back().getCenter()[1] <= -boundaryY + 25)
                stage_idx = 2;

            /// ////////�浹 Ȯ�� �� �� �ֱ�

            if (isCollisionDetected(Linespheres[0], spheres[0]) == true) {
                if ((Linespheres[0].getCenter()[0] + 160) * spheres[0].getCenter()[1] - (Linespheres[0].getCenter()[1]) * (spheres[0].getCenter()[0] + 160) < 0)
                {
                    Linespheres.insert(Linespheres.begin() + 1, spheres[0]);
                }
                else
                {
                    Linespheres.insert(Linespheres.begin(), spheres[0]);
                }
                spheres.erase(spheres.begin());
            }
            if (isCollisionDetected(Linespheres.back(), spheres[0]) == true) {
                if ((Linespheres[Linespheres.size() - 1].getCenter()[0] + 160) * spheres[0].getCenter()[1] - (Linespheres[Linespheres.size() - 1].getCenter()[1]) * (spheres[0].getCenter()[0] + 160) < 0)
                {
                    Linespheres.push_back(spheres[0]);
                }
                else
                {
                    Linespheres.insert(Linespheres.end() - 1, spheres[0]);
                }
                spheres.erase(spheres.begin());
            }
            for (int i = 1; i < Linespheres.size() - 1; i++) {
                if (isCollisionDetected(Linespheres[i], spheres[0]) == true) {

                    if (DistanceSphere(spheres[0], Linespheres[i + 1]) > DistanceSphere(spheres[0], Linespheres[i - 1])) {
                        Linespheres.insert(Linespheres.begin() + i, spheres[0]);
                    }
                    else {
                        Linespheres.insert(Linespheres.begin() + i + 1, spheres[0]);
                    }
                    spheres.erase(spheres.begin());
                }
            }

            /// /////////////////////////////////////�̵� �Ÿ� ���ϱ�
            float dist = sqrt((map.ptr_x[time] - map.ptr_x[time + 1]) * (map.ptr_x[time] - map.ptr_x[time + 1]) + (map.ptr_y[time] - map.ptr_y[time + 1]) * (map.ptr_y[time] - map.ptr_y[time + 1]));
            movelen += dist;
            Linespheres.back().moveLine(time);

            if (Linespheres.front().getCenter()[0] <= map.ptr_x[500] && time_for_keyboard <= 1000)
            {
                time += 8;
                movelen += 8 * dist;
            }
            if (movelen >= 80)
            {
                delta_time.push_back(time);
                movelen = 0;
            }

            /// /////////////////////////////////////�̵� ����
            int pq = 0;

            for (int i = 0; i < Linespheres.size(); i++)
            {
                pq += Linespheres[i].getbomb();
            }

            if (pq != 0)
            {

                time -= 5;
            }
            else { happen_second_crush = 0;  time++; }

            time_for_keyboard++;

            if (delta_time.size() > 0)
            {

                for (int ii = Linespheres.size() - 1, k = 0; ii > -1; k++, ii--)
                {
                    if (time > k * delta_time[0] && delta_time.size() < 10)
                        Linespheres[ii].moveLine(time - k * delta_time[0]);

                    int pqq = 0;
                    int ppqq = 1;
                    for (int i = 0; i < Linespheres.size(); i++)
                    {
                        ppqq = ppqq * Linespheres[i].getbomb();
                        pqq += Linespheres[i].getbomb();
                    }

                    /// ����� �浹���� �ʾ����� 1���� ����
                    if (pqq == 0 && delta_time.size() >= 10)
                    {
                        //0-9
                        Linespheres[k].moveLine(time + (k - 9) * delta_time[0] + zerobomb * delta_time[0]);
                        second_crush = 0;

                    }

                    /// ����� �浹������ 1���� ����
                    if (pqq != 0 && delta_time.size() >= 10)
                    {
                        if (ppqq == 1) //�� true��
                        {
                            for (int p = 0; p < Linespheres.size(); p++)
                            {
                                Linespheres[p].setisbomb(false);
                            }
                            second_crush = 0;
                            break;

                        }
                        Linespheres[k].moveLine(time + (k - 9) * delta_time[0] + inside_bomb * delta_time[0] + (zerobomb)*delta_time[0]);
                        move_ += 5 * (double)1 / (Linespheres.size());
                        if (move_ > (double)1 * ((double)inside_bomb * delta_time[0]))
                        {
                            for (int p = 0; p < Linespheres.size(); p++)
                            {
                                Linespheres[p].setisbomb(false);
                            }
                            time += (inside_bomb)*delta_time[0];

                            move_ = 0;
                            second_crush = 0;
                            inside_bomb = 0;

                        }
                    }

                }
            }
        }
        else
        {
            stage_idx = 4;
        }
        //�� ���� �� �����
        bool d0_not_start_bomb = true;
        for (int i = 0; i < Linespheres.size(); i++)
        {
            d0_not_start_bomb *= Linespheres[i].get_on_the_sphere();
        }
        // �� 8��
        if (Linespheres.size() > 7 && d0_not_start_bomb == false)
        {
            for (int i = 0; i < Linespheres.size() - 7; i++) {
                if (second_crush > 0) {

                    break;
                }
                if (second_crush == 0 && isSameDetected_8(Linespheres[i], Linespheres[i + 1], Linespheres[i + 2], Linespheres[i + 3], Linespheres[i + 4], Linespheres[i + 5], Linespheres[i + 6], Linespheres[i + 7]) == true)
                {

                    bool can_not_bomb = true;
                    for (int m = 0; m < 8; m++)
                        can_not_bomb *= Linespheres[i + m].get_on_the_sphere();

                    Linespheres[i].set_on_the_sphere(false);
                    if (can_not_bomb == false)
                    {
                        happen_second_crush++;
                        second_crush++;
                        for (int j = 0; j < 8; j++)
                            Linespheres.erase(Linespheres.begin() + i);

                        if (Linespheres.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres[i - 1], Linespheres[i]))
                            {
                                Linespheres[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0) {
                            zerobomb += 7;
                            if (happen_second_crush > 1)
                                zerobomb += (1);
                        }
                        else {
                            if (i != Linespheres.size())
                                inside_bomb += 7;
                            else
                                inside_bomb += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��7��
        if (Linespheres.size() > 6 && d0_not_start_bomb == false)
        {
            for (int i = 0; i < Linespheres.size() - 6; i++) {
                if (second_crush > 0) {

                    break;
                }
                if (second_crush == 0 && isSameDetected_7(Linespheres[i], Linespheres[i + 1], Linespheres[i + 2], Linespheres[i + 3], Linespheres[i + 4], Linespheres[i + 5], Linespheres[i + 6]) == true)
                {

                    bool can_not_bomb = true;
                    for (int m = 0; m < 7; m++)
                        can_not_bomb *= Linespheres[i + m].get_on_the_sphere();

                    Linespheres[i].set_on_the_sphere(false);
                    if (can_not_bomb == false)
                    {
                        happen_second_crush++;
                        second_crush++;
                        for (int j = 0; j < 7; j++)
                            Linespheres.erase(Linespheres.begin() + i);

                        if (Linespheres.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres[i - 1], Linespheres[i]))
                            {
                                Linespheres[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0) {
                            zerobomb += 6;
                            if (happen_second_crush > 1)
                                zerobomb += (1);
                        }
                        else {
                            if (i != Linespheres.size())
                                inside_bomb += 6;
                            else
                                inside_bomb += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��6��
        if (Linespheres.size() > 5 && d0_not_start_bomb == false)
        {
            for (int i = 0; i < Linespheres.size() - 5; i++) {
                if (second_crush > 0) {

                    break;
                }
                if (second_crush == 0 && isSameDetected_6(Linespheres[i], Linespheres[i + 1], Linespheres[i + 2], Linespheres[i + 3], Linespheres[i + 4], Linespheres[i + 5]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 6; m++)
                        can_not_bomb *= Linespheres[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush++;
                        second_crush++;
                        for (int j = 0; j < 6; j++)
                            Linespheres.erase(Linespheres.begin() + i);

                        if (Linespheres.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres[i - 1], Linespheres[i]))
                            {
                                Linespheres[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0) {
                            zerobomb += 5;
                            if (happen_second_crush > 1)
                                zerobomb += (1);

                        }
                        else {
                            if (i != Linespheres.size())
                                inside_bomb += 5;
                            else
                                inside_bomb += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��5��
        if (Linespheres.size() > 4 && d0_not_start_bomb == false)
        {
            for (int i = 0; i < Linespheres.size() - 4; i++) {

                if (second_crush > 0) {

                    break;
                }
                if (second_crush == 0 && isSameDetected_5(Linespheres[i], Linespheres[i + 1], Linespheres[i + 2], Linespheres[i + 3], Linespheres[i + 4]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 5; m++)
                        can_not_bomb *= Linespheres[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush++;
                        second_crush++;
                        for (int j = 0; j < 5; j++)
                            Linespheres.erase(Linespheres.begin() + i);

                        if (Linespheres.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres[i - 1], Linespheres[i]))
                            {
                                Linespheres[i].set_on_the_sphere(false);
                            }
                        }

                        if (i == 0) {
                            zerobomb += 4;
                            if (happen_second_crush > 1)
                                zerobomb += (1);
                        }
                        else {
                            if (i != Linespheres.size())
                                inside_bomb += 4;
                            else
                                inside_bomb += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��4��
        if (Linespheres.size() > 3 && d0_not_start_bomb == false)
        {
            for (int i = 0; i < Linespheres.size() - 3; i++) {
                if (second_crush > 0) {

                    break;
                }
                if (second_crush == 0 && isSameDetected_4(Linespheres[i], Linespheres[i + 1], Linespheres[i + 2], Linespheres[i + 3]) == true)
                {
                    bool can_not_bomb = true;

                    for (int m = 0; m < 4; m++)
                        can_not_bomb *= Linespheres[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush++;
                        second_crush++;
                        for (int j = 0; j < 4; j++)
                            Linespheres.erase(Linespheres.begin() + i);

                        if (Linespheres.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres[i - 1], Linespheres[i]))
                            {
                                Linespheres[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0) {
                            zerobomb += 3;
                            if (happen_second_crush > 1)
                                zerobomb += (1);

                        }
                        else {
                            if (i != Linespheres.size())
                                inside_bomb += 3;
                            else
                                inside_bomb += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��3��
        if (Linespheres.size() > 2 && d0_not_start_bomb == false)
        {
            for (int i = 0; i < Linespheres.size() - 2; i++) {
                if (second_crush > 0)
                {
                    break;
                }
                if (second_crush == 0 && isSameDetected(Linespheres[i], Linespheres[i + 1], Linespheres[i + 2]) == true)
                {
                    bool can_not_bomb = true;

                    for (int m = 0; m < 3; m++)
                        can_not_bomb *= Linespheres[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush++;
                        second_crush++;
                        for (int j = 0; j < 3; j++)
                            Linespheres.erase(Linespheres.begin() + i);

                        if (Linespheres.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres[i - 1], Linespheres[i]) == true)
                            {
                                Linespheres[i].set_on_the_sphere(false);
                            }
                        }

                        if (i == 0) {
                            zerobomb += 2;
                            if (happen_second_crush > 1)
                                zerobomb += (1);

                        }
                        else {
                            if (i != Linespheres.size())
                                inside_bomb += 2;
                            else
                                inside_bomb += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres[p].setisbomb(true);
                        }
                        break;
                    }
                }
            }
        }
        if (second_crush > 1)
        {
            for (int i = 0; i < Linespheres.size(); i++)
            {
                Linespheres[i].set_on_the_sphere(true);
            }
        }

        if (spheres[0].getLaunchtrue() == true) {
            spheres[0].launch();
            if (spheres[0].getCenter()[0] > boundaryX * 2 / 3 || spheres[0].getCenter()[0] < -boundaryX - spheres[0].getRadius()
                || abs(spheres[0].getCenter()[1]) > spheres[0].getRadius() + boundaryY) {
                spheres.erase(spheres.begin());
            }
        }
    }
    int stage2done = 0;
    //////////////////////stage Change///////////////////////////////
    if (stage_idx == 3) {
        if (Linespheres1.size() != 0)
        {
            /////////////////////////////////�浹 ����
            if (time_for_keyboard1 > 1000 && Linespheres1.back().getCenter()[1] <= -boundaryY + 25)
                stage_idx = 2;

            /// ////////�浹 Ȯ�� �� �� �ֱ�
            if (isCollisionDetected(Linespheres1[0], spheres[0]) == true) {
                if ((Linespheres1[0].getCenter()[0] + 160) * spheres[0].getCenter()[1] - (Linespheres1[0].getCenter()[1]) * (spheres[0].getCenter()[0] + 160) < 0)
                {
                    Linespheres1.insert(Linespheres1.begin() + 1, spheres[0]);
                }
                else
                {
                    Linespheres1.insert(Linespheres1.begin(), spheres[0]);
                }
                spheres.erase(spheres.begin());
            }
            if (isCollisionDetected(Linespheres1.back(), spheres[0]) == true) {
                if ((Linespheres1[Linespheres1.size() - 1].getCenter()[0] + 160) * spheres[0].getCenter()[1] - (Linespheres1[Linespheres1.size() - 1].getCenter()[1]) * (spheres[0].getCenter()[0] + 160) < 0)
                {
                    Linespheres1.push_back(spheres[0]);
                }
                else
                {
                    Linespheres1.insert(Linespheres1.end() - 1, spheres[0]);
                }
                spheres.erase(spheres.begin());
            }
            for (int i = 1; i < Linespheres1.size() - 1; i++) {
                if (isCollisionDetected(Linespheres1[i], spheres[0]) == true) {

                    if (DistanceSphere(spheres[0], Linespheres1[i + 1]) > DistanceSphere(spheres[0], Linespheres1[i - 1])) {
                        Linespheres1.insert(Linespheres1.begin() + i, spheres[0]);
                    }
                    else {
                        Linespheres1.insert(Linespheres1.begin() + i + 1, spheres[0]);
                    }
                    spheres.erase(spheres.begin());
                }
            }

            /// /////////////////////////////////////�̵� �Ÿ� ���ϱ�
            float dist = sqrt((map1.ptr_x[time1] - map1.ptr_x[time1 + 1]) * (map1.ptr_x[time1] - map1.ptr_x[time1 + 1]) + (map1.ptr_y[time1] - map1.ptr_y[time1 + 1]) * (map1.ptr_y[time1] - map1.ptr_y[time1 + 1]));
            movelen1 += dist;
            Linespheres1.back().moveLine(time1);

            if (Linespheres1.front().getCenter()[0] <= map1.ptr_x[500] && time_for_keyboard1 <= 1000)
            {
                time1 += 8;
                movelen1 += 8 * dist;
            }
            if (movelen1 >= 80)
            {
                delta_time1.push_back(time1);
                movelen1 = 0;
            }

            /// /////////////////////////////////////�̵� ����
            int pq = 0;

            for (int i = 0; i < Linespheres1.size(); i++)
            {
                pq += Linespheres1[i].getbomb();
            }

            if (pq != 0) { time1 -= 5; }
            else { happen_second_crush1 = 0; time1++; }

            time_for_keyboard1++;

            if (delta_time1.size() > 0)
            {

                for (int ii = Linespheres1.size() - 1, k = 0; ii > -1; k++, ii--)
                {
                    if (time1 > k * delta_time1[0] && delta_time1.size() < 10)
                        Linespheres1[ii].moveLine(time1 - k * delta_time1[0]);

                    int pqq = 0;
                    int ppqq = 1;
                    for (int i = 0; i < Linespheres1.size(); i++)
                    {
                        ppqq = ppqq * Linespheres1[i].getbomb();
                        pqq += Linespheres1[i].getbomb();
                    }

                    /// ����� �浹���� �ʾ����� 1���� ����
                    if (pqq == 0 && delta_time1.size() >= 10)
                    {
                        //0-9
                        Linespheres1[k].moveLine(time1 + (k - 9) * delta_time1[0] + zerobomb1 * delta_time1[0]);
                        second_crush1 = 0;
                    }

                    /// ����� �浹������ 1���� ����
                    if (pqq != 0 && delta_time1.size() >= 10)
                    {
                        if (ppqq == 1) //�� true��
                        {
                            for (int p = 0; p < Linespheres1.size(); p++)
                            {
                                Linespheres1[p].setisbomb(false);
                            }
                            second_crush1 = 0;
                            break;

                        }
                        Linespheres1[k].moveLine(time1 + (k - 9) * delta_time1[0] + inside_bomb1 * delta_time1[0] + zerobomb1 * delta_time1[0]);
                        move_1 += 5 * (double)1 / (Linespheres1.size());
                        if (move_1 > (double)inside_bomb1 * delta_time1[0])
                        {
                            for (int p = 0; p < Linespheres1.size(); p++)
                            {
                                Linespheres1[p].setisbomb(false);
                            }
                            time1 += inside_bomb1 * delta_time1[0];
                            move_1 = 0;
                            second_crush1 = 0;
                            inside_bomb1 = 0;
                        }
                    }

                }
            }
        }
        else
        {
            stage2done++;
        }
        //�� ���� �� �����
        bool d0_not_start_bomb = true;
        for (int i = 0; i < Linespheres1.size(); i++)
        {
            d0_not_start_bomb = d0_not_start_bomb * Linespheres1[i].get_on_the_sphere();
        }
        // ��8��
        if (Linespheres1.size() > 6 && d0_not_start_bomb == false)
        {
            for (int i = 0; i < Linespheres1.size() - 7; i++) {
                if (second_crush1 > 0) {
                    break;
                }
                if (second_crush1 == 0 && isSameDetected_8(Linespheres1[i], Linespheres1[i + 1], Linespheres1[i + 2], Linespheres1[i + 3], Linespheres1[i + 4], Linespheres1[i + 5], Linespheres1[i + 6], Linespheres1[i + 7]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 8; m++)
                        can_not_bomb *= Linespheres1[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush1++;
                        second_crush1++;
                        for (int j = 0; j < 8; j++)
                            Linespheres1.erase(Linespheres1.begin() + i);

                        if (Linespheres1.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres1[i - 1], Linespheres1[i]))
                            {
                                Linespheres1[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0) {
                            zerobomb1 += 7;
                            if (happen_second_crush1 > 1)
                                zerobomb1++;
                        }
                        else {
                            if (i != Linespheres1.size())
                                inside_bomb1 += 7;
                            else
                                inside_bomb1 += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres1[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��7��
        if (Linespheres1.size() > 6 && d0_not_start_bomb == false)
        {
            for (int i = 0; i < Linespheres1.size() - 6; i++) {
                if (second_crush1 > 0) {
                    break;
                }
                if (second_crush1 == 0 && isSameDetected_7(Linespheres1[i], Linespheres1[i + 1], Linespheres1[i + 2], Linespheres1[i + 3], Linespheres1[i + 4], Linespheres1[i + 5], Linespheres1[i + 6]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 7; m++)
                        can_not_bomb *= Linespheres1[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush1++;
                        second_crush1++;
                        for (int j = 0; j < 7; j++)
                            Linespheres1.erase(Linespheres1.begin() + i);

                        if (Linespheres1.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres1[i - 1], Linespheres1[i]))
                            {
                                Linespheres1[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0) {
                            zerobomb1 += 6;
                            if (happen_second_crush1 > 1)
                                zerobomb1++;
                        }
                        else {
                            if (i != Linespheres1.size())
                                inside_bomb1 += 6;
                            else
                                inside_bomb1 += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres1[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��6��
        if (Linespheres1.size() > 5 && d0_not_start_bomb == false)
        {
            for (int i = 0; i < Linespheres1.size() - 5; i++) {
                if (second_crush1 > 0) {

                    break;
                }
                if (second_crush1 == 0 && isSameDetected_6(Linespheres1[i], Linespheres1[i + 1], Linespheres1[i + 2], Linespheres1[i + 3], Linespheres1[i + 4], Linespheres1[i + 5]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 6; m++)
                        can_not_bomb *= Linespheres1[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush1++;
                        second_crush1++;
                        for (int j = 0; j < 6; j++)
                            Linespheres1.erase(Linespheres1.begin() + i);

                        if (Linespheres1.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres1[i - 1], Linespheres1[i]))
                            {
                                Linespheres1[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0) {
                            zerobomb1 += 5;
                            if (happen_second_crush1 > 1)
                                zerobomb1++;
                        }
                        else {
                            if (i != Linespheres1.size())
                                inside_bomb1 += 5;
                            else
                                inside_bomb1 += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres1[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��5��
        if (Linespheres1.size() > 4 && d0_not_start_bomb == false)
        {
            for (int i = 0; i < Linespheres1.size() - 4; i++) {
                if (second_crush1 > 0) {

                    break;
                }
                if (second_crush1 == 0 && isSameDetected_5(Linespheres1[i], Linespheres1[i + 1], Linespheres1[i + 2], Linespheres1[i + 3], Linespheres1[i + 4]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 5; m++)
                        can_not_bomb *= Linespheres1[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush1++;
                        second_crush1++;
                        for (int j = 0; j < 5; j++)
                            Linespheres1.erase(Linespheres1.begin() + i);

                        if (Linespheres1.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres1[i - 1], Linespheres1[i]))
                            {
                                Linespheres1[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0) {
                            zerobomb1 += 4;
                            if (happen_second_crush1 > 1)
                                zerobomb1++;
                        }
                        else {
                            if (i != Linespheres1.size())
                                inside_bomb1 += 4;
                            else
                                inside_bomb1 += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres1[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��4��
        if (Linespheres1.size() > 3 && d0_not_start_bomb == false)
        {
            for (int i = 0; i < Linespheres1.size() - 3; i++) {
                if (second_crush1 > 0) {

                    break;
                }
                if (second_crush1 == 0 && isSameDetected_4(Linespheres1[i], Linespheres1[i + 1], Linespheres1[i + 2], Linespheres1[i + 3]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 4; m++)
                        can_not_bomb *= Linespheres1[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush1++;
                        second_crush1++;
                        for (int j = 0; j < 4; j++)
                            Linespheres1.erase(Linespheres1.begin() + i);

                        if (Linespheres1.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres1[i - 1], Linespheres1[i]))
                            {
                                Linespheres1[i].set_on_the_sphere(false);
                            }
                        }

                        if (i == 0) {
                            zerobomb1 += 3;
                            if (happen_second_crush1 > 1)
                                zerobomb1++;
                        }
                        else {
                            if (i != Linespheres1.size())
                                inside_bomb1 += 3;
                            else
                                inside_bomb1 += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres1[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��3��
        if (Linespheres1.size() > 2 && d0_not_start_bomb == false)
        {
            for (int i = 0; i < Linespheres1.size() - 2; i++) {
                if (second_crush1 > 0)
                {
                    break;
                }
                if (second_crush1 == 0 && isSameDetected(Linespheres1[i], Linespheres1[i + 1], Linespheres1[i + 2]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 3; m++)
                        can_not_bomb *= Linespheres1[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush1++;
                        second_crush1++;
                        for (int j = 0; j < 3; j++)
                            Linespheres1.erase(Linespheres1.begin() + i);

                        if (Linespheres1.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres1[i - 1], Linespheres1[i]))
                            {
                                Linespheres1[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0) {
                            zerobomb1 += 2;
                            if (happen_second_crush1 > 1)
                                zerobomb1++;
                        }
                        else {
                            if (i != Linespheres1.size())
                                inside_bomb1 += 2;
                            else
                                inside_bomb1 += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres1[p].setisbomb(true);
                        }
                        break;
                    }
                }
            }
        }
        if (second_crush1 > 1)
        {
            for (int i = 0; i < Linespheres1.size(); i++)
            {
                Linespheres1[i].set_on_the_sphere(true);
            }
        }

        if (spheres[0].getLaunchtrue() == true) {
            spheres[0].launch();
            if (spheres[0].getCenter()[0] > boundaryX * 2 / 3 || spheres[0].getCenter()[0] < -boundaryX - spheres[0].getRadius()
                || abs(spheres[0].getCenter()[1]) > spheres[0].getRadius() + boundaryY) {
                spheres.erase(spheres.begin());
            }
        }

        //////////////////////////////

        if (Linespheres2.size() != 0)
        {
            /////////////////////////////////�浹 ����
            if (time_for_keyboard1 > 1000 && Linespheres2.back().getCenter()[1] >= boundaryY - 25)
                stage_idx = 2;

            /// ////////�浹 Ȯ�� �� �� �ֱ�
            if (isCollisionDetected(Linespheres2[0], spheres[0]) == true) {
                if ((Linespheres2[0].getCenter()[0] + 160) * spheres[0].getCenter()[1] - (Linespheres2[0].getCenter()[1]) * (spheres[0].getCenter()[0] + 160) < 0)
                {
                    Linespheres2.insert(Linespheres2.begin() + 1, spheres[0]);
                }
                else
                {
                    Linespheres2.insert(Linespheres2.begin(), spheres[0]);
                }
                spheres.erase(spheres.begin());
            }
            if (isCollisionDetected(Linespheres2.back(), spheres[0]) == true) {
                if ((Linespheres2[Linespheres2.size() - 1].getCenter()[0] + 160) * spheres[0].getCenter()[1] - (Linespheres2[Linespheres2.size() - 1].getCenter()[1]) * (spheres[0].getCenter()[0] + 160) < 0)
                {
                    Linespheres2.push_back(spheres[0]);
                }
                else
                {
                    Linespheres2.insert(Linespheres2.end() - 1, spheres[0]);
                }
                spheres.erase(spheres.begin());
            }
            for (int i = 1; i < Linespheres2.size() - 1; i++) {
                if (isCollisionDetected(Linespheres2[i], spheres[0]) == true) {

                    if (DistanceSphere(spheres[0], Linespheres2[i + 1]) > DistanceSphere(spheres[0], Linespheres2[i - 1])) {
                        Linespheres2.insert(Linespheres2.begin() + i, spheres[0]);
                    }
                    else {
                        Linespheres2.insert(Linespheres2.begin() + i + 1, spheres[0]);
                    }
                    spheres.erase(spheres.begin());
                }
            }

            /// /////////////////////////////////////�̵� �Ÿ� ���ϱ�
            float dist = sqrt((map2.ptr_x[time2] - map2.ptr_x[time2 + 1]) * (map2.ptr_x[time2] - map2.ptr_x[time2 + 1]) + (map2.ptr_y[time2] - map2.ptr_y[time2 + 1]) * (map2.ptr_y[time2] - map2.ptr_y[time2 + 1]));
            movelen2 += dist;
            Linespheres2.back().moveLine2(time2);

            if (Linespheres2.front().getCenter()[0] >= map2.ptr_x[500] && time_for_keyboard2 <= 1000)
            {
                time2 += 8;
                movelen2 += 8 * dist;
            }
            if (movelen2 >= 80)
            {
                delta_time2.push_back(time2);
                movelen2 = 0;
            }

            /// /////////////////////////////////////�̵� ����
            int pq = 0;

            for (int i = 0; i < Linespheres2.size(); i++)
            {
                pq += Linespheres2[i].getbomb();
            }

            if (pq != 0) { time2 -= 5; }
            else { happen_second_crush2 = 0; time2++; }

            time_for_keyboard2++;

            if (delta_time2.size() > 0)
            {

                for (int ii = Linespheres2.size() - 1, k = 0; ii > -1; k++, ii--)
                {
                    if (time2 > k * delta_time2[0] && delta_time2.size() < 10)
                        Linespheres2[ii].moveLine2(time2 - k * delta_time2[0]);

                    int pqq = 0;
                    int ppqq = 1;
                    for (int i = 0; i < Linespheres2.size(); i++)
                    {
                        ppqq = ppqq * Linespheres2[i].getbomb();
                        pqq += Linespheres2[i].getbomb();
                    }

                    /// ����� �浹���� �ʾ����� 1���� ����
                    if (pqq == 0 && delta_time2.size() >= 10)
                    {
                        //0-9
                        Linespheres2[k].moveLine2(time2 + (k - 9) * delta_time2[0] + zerobomb2 * delta_time2[0]);
                        second_crush2 = 0;
                    }

                    /// ����� �浹������ 1���� ����
                    if (pqq != 0 && delta_time2.size() >= 10)
                    {
                        if (ppqq == 1) //�� true��
                        {
                            for (int p = 0; p < Linespheres2.size(); p++)
                            {
                                Linespheres2[p].setisbomb(false);
                            }
                            second_crush2 = 0;
                            break;

                        }
                        Linespheres2[k].moveLine2(time2 + (k - 9) * delta_time2[0] + inside_bomb2 * delta_time2[0] + zerobomb2 * delta_time2[0]);
                        move_2 += 5 * (double)1 / (Linespheres2.size());
                        if (move_2 > (double)inside_bomb2 * delta_time2[0])
                        {
                            for (int p = 0; p < Linespheres2.size(); p++)
                            {
                                Linespheres2[p].setisbomb(false);
                            }
                            time2 += inside_bomb2 * delta_time2[0];
                            move_2 = 0;
                            second_crush2 = 0;
                            inside_bomb2 = 0;
                        }
                    }

                }
            }
        }
        else
        {
            stage2done++;
        }
        //�� ���� �� �����
        bool d0_not_start_bomb_1 = true;
        for (int i = 0; i < Linespheres2.size(); i++)
        {
            d0_not_start_bomb_1 *= Linespheres2[i].get_on_the_sphere();
        }
        // ��8��
        if (Linespheres2.size() > 7 && d0_not_start_bomb_1 == false)
        {
            for (int i = 0; i < Linespheres2.size() - 7; i++) {
                if (second_crush2 > 0) {

                    break;
                }
                if (second_crush2 == 0 && isSameDetected_8(Linespheres2[i], Linespheres2[i + 1], Linespheres2[i + 2], Linespheres2[i + 3], Linespheres2[i + 4], Linespheres2[i + 5], Linespheres2[i + 6], Linespheres2[i + 7]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 8; m++)
                        can_not_bomb *= Linespheres2[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush2++;
                        second_crush2++;
                        for (int j = 0; j < 8; j++)
                            Linespheres2.erase(Linespheres2.begin() + i);

                        if (Linespheres2.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres2[i - 1], Linespheres2[i]))
                            {
                                Linespheres2[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0)
                        {
                            zerobomb2 += 7;
                            if (happen_second_crush2 > 1)
                                zerobomb2++;
                        }
                        else {
                            if (i != Linespheres2.size())
                                inside_bomb2 += 7;
                            else
                                inside_bomb2 += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres2[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��7��
        if (Linespheres2.size() > 6 && d0_not_start_bomb_1 == false)
        {
            for (int i = 0; i < Linespheres2.size() - 6; i++) {
                if (second_crush2 > 0) {

                    break;
                }
                if (second_crush2 == 0 && isSameDetected_7(Linespheres2[i], Linespheres2[i + 1], Linespheres2[i + 2], Linespheres2[i + 3], Linespheres2[i + 4], Linespheres2[i + 5], Linespheres2[i + 6]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 7; m++)
                        can_not_bomb *= Linespheres2[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush2++;
                        second_crush2++;
                        for (int j = 0; j < 7; j++)
                            Linespheres2.erase(Linespheres2.begin() + i);

                        if (Linespheres2.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres2[i - 1], Linespheres2[i]))
                            {
                                Linespheres2[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0)
                        {
                            zerobomb2 += 6;
                            if (happen_second_crush2 > 1)
                                zerobomb2++;
                        }
                        else {
                            if (i != Linespheres2.size())
                                inside_bomb2 += 6;
                            else
                                inside_bomb2 += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres2[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��6��
        if (Linespheres2.size() > 5 && d0_not_start_bomb_1 == false)
        {
            for (int i = 0; i < Linespheres2.size() - 5; i++) {
                if (second_crush2 > 0) {

                    break;
                }
                if (second_crush2 == 0 && isSameDetected_6(Linespheres2[i], Linespheres2[i + 1], Linespheres2[i + 2], Linespheres2[i + 3], Linespheres2[i + 4], Linespheres2[i + 5]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 6; m++)
                        can_not_bomb *= Linespheres2[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush2++;
                        second_crush2++;
                        for (int j = 0; j < 6; j++)
                            Linespheres2.erase(Linespheres2.begin() + i);

                        if (Linespheres2.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres2[i - 1], Linespheres2[i]))
                            {
                                Linespheres2[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0)
                        {
                            zerobomb2 += 5;
                            if (happen_second_crush2 > 1)
                                zerobomb2++;
                        }
                        else {
                            if (i != Linespheres2.size())
                                inside_bomb2 += 5;
                            else
                                inside_bomb2 += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres2[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��5��
        if (Linespheres2.size() > 4 && d0_not_start_bomb_1 == false)
        {
            for (int i = 0; i < Linespheres2.size() - 4; i++) {
                if (second_crush2 > 0) {

                    break;
                }
                if (second_crush2 == 0 && isSameDetected_5(Linespheres2[i], Linespheres2[i + 1], Linespheres2[i + 2], Linespheres2[i + 3], Linespheres2[i + 4]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 5; m++)
                        can_not_bomb *= Linespheres2[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush2;
                        second_crush2++;
                        for (int j = 0; j < 5; j++)
                            Linespheres2.erase(Linespheres2.begin() + i);

                        if (Linespheres2.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres2[i - 1], Linespheres2[i]))
                            {
                                Linespheres2[i].set_on_the_sphere(false);
                            }
                        }
                        if (i == 0)
                        {
                            zerobomb2 += 4;
                            if (happen_second_crush2 > 1)
                                zerobomb2++;
                        }
                        else {
                            if (i != Linespheres2.size())
                                inside_bomb2 += 4;
                            else
                                inside_bomb2 += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres2[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��4��
        if (Linespheres2.size() > 3 && d0_not_start_bomb_1 == false)
        {
            for (int i = 0; i < Linespheres2.size() - 3; i++) {
                if (second_crush2 > 0) {

                    break;
                }
                if (second_crush2 == 0 && isSameDetected_4(Linespheres2[i], Linespheres2[i + 1], Linespheres2[i + 2], Linespheres2[i + 3]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 4; m++)
                        can_not_bomb *= Linespheres2[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush2++;
                        second_crush2++;
                        for (int j = 0; j < 4; j++)
                            Linespheres2.erase(Linespheres2.begin() + i);

                        if (Linespheres2.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres2[i - 1], Linespheres2[i]))
                            {
                                Linespheres2[i].set_on_the_sphere(false);
                            }
                        }

                        if (i == 0)
                        {
                            zerobomb2 += 3;
                            if (happen_second_crush2 > 1)
                                zerobomb2++;
                        }
                        else {
                            if (i != Linespheres2.size())
                                inside_bomb2 += 3;
                            else
                                inside_bomb2 += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres2[p].setisbomb(true);
                        }
                        break;
                    }
                }

            }
        }
        // ��3��
        if (Linespheres2.size() > 2 && d0_not_start_bomb_1 == false)
        {
            for (int i = 0; i < Linespheres2.size() - 2; i++) {
                if (second_crush2 > 0)
                {

                    break;
                }
                if (second_crush2 == 0 && isSameDetected(Linespheres2[i], Linespheres2[i + 1], Linespheres2[i + 2]) == true)
                {
                    bool can_not_bomb = true;
                    for (int m = 0; m < 3; m++)
                        can_not_bomb *= Linespheres2[i + m].get_on_the_sphere();

                    if (can_not_bomb == false)
                    {
                        happen_second_crush2++;
                        second_crush2++;
                        for (int j = 0; j < 3; j++)
                            Linespheres2.erase(Linespheres2.begin() + i);

                        if (Linespheres2.size() > i && i != 0)
                        {
                            if (isSameDetected_2(Linespheres2[i - 1], Linespheres2[i]))
                            {
                                Linespheres2[i].set_on_the_sphere(false);
                            }
                        }

                        if (i == 0)
                        {
                            zerobomb2 += 2;
                            if (happen_second_crush2 > 1)
                                zerobomb2++;
                        }
                        else {
                            if (i != Linespheres2.size())
                                inside_bomb2 += 2;
                            else
                                inside_bomb2 += 0;
                        }
                        for (int p = 0; p < i; p++)
                        {
                            Linespheres2[p].setisbomb(true);
                        }
                        break;
                    }
                }
            }
        }
        if (second_crush2 > 1)
        {
            for (int i = 0; i < Linespheres2.size(); i++)
            {
                Linespheres2[i].set_on_the_sphere(true);
            }
            int a = 0;
        }

        if (spheres[0].getLaunchtrue() == true) {
            spheres[0].launch();
            if (spheres[0].getCenter()[0] > boundaryX * 2 / 3 || spheres[0].getCenter()[0] < -boundaryX - spheres[0].getRadius()
                || abs(spheres[0].getCenter()[1]) > spheres[0].getRadius() + boundaryY) {
                spheres.erase(spheres.begin());
            }
        }
        if (stage2done == 2)
            stage_idx = 5;
    }
    if (end_t - start_t > 1000 / 60) {
        start_t = end_t;

    }

    glutPostRedisplay();
}


void display() {
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-boundaryX, boundaryX, -boundaryY, boundaryY, -100.0, 100.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    /* Implement: Draw 2D (texture, ID and name)*/
    if (stage_idx == 0) {
        glColor3f(1.0f, 1.f, 1.f);
        GameStart.drawSquareWithTextureStage();
        GameStart.displayCharacters(GLUT_BITMAP_TIMES_ROMAN_24, "Press 's' to Start", -100, -WINDOW_HEIGHT / 2.5);
    }
    if (stage_idx == 2) {
        glColor3f(1.0f, 1.f, 1.f);
        GameOver.drawSquareWithTextureStage();
        GameOver.displayCharacters(GLUT_BITMAP_TIMES_ROMAN_24, "Press 'ESC' to Exit", -140, -WINDOW_HEIGHT / 2.5);
    }
    if (stage_idx == 4) {
        glColor3f(1.0f, 1.f, 1.f);
        StageClear.drawSquareWithTextureStage();
        StageClear.displayCharacters(GLUT_BITMAP_TIMES_ROMAN_24, "Press 's' to Start Next Stage", -200, -WINDOW_HEIGHT / 2.5);
    }
    if (stage_idx == 5) {
        glColor3f(1.0f, 1.f, 1.f);
        StageClear.drawSquareWithTextureStage();
        StageClear.displayCharacters(GLUT_BITMAP_TIMES_ROMAN_24, "Press 'Esc' to Exit", -140, -WINDOW_HEIGHT / 2.5);
    }
    if (stage_idx == 1 || stage_idx == 3) {
        Img.drawSquareWithTextureStage2();
        texture.drawSquareWithTexture();
        glColor3f(1.0f, 1.f, 1.f);
        glColor3f(1.0f, 1.f, 0.f);
        texture.displayCharacters(GLUT_BITMAP_HELVETICA_18, "SPACEBAR LAUNCH", 0.7f * WINDOW_WIDTH / 2, -0.8f * WINDOW_HEIGHT / 2);

        if (stage_idx == 1)
            map.drawmap(map.ptr_x, map.ptr_y);
        if (stage_idx == 3) {
            map1.drawmap(map1.ptr_x, map1.ptr_y);
            map2.drawmap(map2.ptr_x, map2.ptr_y);
        }

        glPointSize(2.f);
        glBegin(GL_POINTS);
        if (spheres.size() == 2) {
            for (int i = 0; i < 100; i++) {
                float x_gap = spheres[0].getCenter()[0] - spheres[1].getCenter()[0];
                float y_gap = spheres[0].getCenter()[1] - spheres[1].getCenter()[1];
                glVertex3f(spheres[1].getCenter()[0] + x_gap * i / 6, spheres[1].getCenter()[1] + y_gap * i / 6, 0);
            }
        }
        else {
            for (int i = 0; i < 100; i++) {
                float x_gap = spheres[1].getCenter()[0] - spheres[2].getCenter()[0];
                float y_gap = spheres[1].getCenter()[1] - spheres[2].getCenter()[1];
                glVertex3f(spheres[1].getCenter()[0] + x_gap * i / 6, spheres[1].getCenter()[1] + y_gap * i / 6, 0);
            }
        }
        glEnd();

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);

        light.draw();

        glPushMatrix();
        glTranslatef(Canon.getCenter()[0], Canon.getCenter()[1], Canon.getCenter()[2]);
        glRotatef(Angle * 180 / 3.14159265f + 22.5f, 0, 0, 1);
        Canon.CanonDraw();
        glPopMatrix();
        if (stage_idx == 1) {
            for (int i = 0; i < Linespheres.size(); i++)
            {
                Linespheres[i].draw();
            }
        }
        if (stage_idx == 3) {
            for (int i = 0; i < Linespheres1.size(); i++)
            {
                Linespheres1[i].draw();
            }
            for (int i = 0; i < Linespheres2.size(); i++)
            {
                Linespheres2[i].draw();
            }
        }

        spheres[0].draw();
        spheres[1].draw();
        if (spheres[0].getLaunchtrue() == true)
            spheres[2].draw();

        glDisable(GL_LIGHT0);
        glDisable(GL_LIGHTING);
        glDisable(GL_DEPTH_TEST);
    }

    glutSwapBuffers();
}

void keyboardDown(unsigned char key, int x, int y) {
    if (stage_idx == 1) {
        if (time_for_keyboard > 400 && spheres.size() == 2) {
            if (spheres.size() == 2) {
                if (key == ' ') {
                    spheres[0].launch();
                    spheres[1].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0.f);
                    spheres[1].setVelocity(2 * cos(Angle), 2 * sin(Angle), 0.0f);
                    tempSphere.makeSphere();
                    tempSphere.set_on_the_sphere(false);
                    spheres.push_back(tempSphere);
                }
            }
        }
    }
    if (stage_idx == 3) {
        if (time_for_keyboard1 > 400 && spheres.size() == 2) {
            if (spheres.size() == 2) {
                if (key == ' ') {
                    spheres[0].launch();
                    spheres[1].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0.f);
                    spheres[1].setVelocity(2 * cos(Angle), 2 * sin(Angle), 0.0f);
                    tempSphere.makeSphere();
                    tempSphere.set_on_the_sphere(false);
                    spheres.push_back(tempSphere);
                }
            }
        }
    }
    if (key == 27)
        exit(0);
    if (stage_idx == 0) {
        if (key == 's')
            stage_idx = 1;
    }
    if (stage_idx == 2) {
        if (key == 27)
            exit(0);
    }
    if (stage_idx == 4) {
        if (key == 's')
            stage_idx = 3;
    }
}

void specialKeyDown(int key, int x, int y) {

    float a = Angle / 3.14159265f * 180 + 36000;
    if (spheres.size() == 2) {
        switch (key) {
        case GLUT_KEY_UP:
            if ((int)a % 360 < 270 && (int)a % 360 > 90) {
                Angle -= AngVel;
                spheres[0].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
            else {
                Angle += AngVel;
                spheres[0].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
        case GLUT_KEY_DOWN:
            if ((int)a % 360 < 270 && (int)a % 360 > 90) {
                Angle += AngVel;
                spheres[0].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
            else {
                Angle -= AngVel;
                spheres[0].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
        case GLUT_KEY_LEFT:
            if ((int)a % 360 < 180 && (int)a % 360 > 0) {
                if (a < 0)
                    Angle -= AngVel;
                else
                    Angle += AngVel;
                spheres[0].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
            else {
                if (a < 0)
                    Angle += AngVel;
                else
                    Angle -= AngVel;
                spheres[0].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
        case GLUT_KEY_RIGHT:

            if ((int)a % 360 < 180 && (int)a % 360 > 0) {
                if (a < 0)
                    Angle += AngVel;
                else
                    Angle -= AngVel;
                spheres[0].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
            else {
                if (a < 0)
                    Angle -= AngVel;
                else
                    Angle += AngVel;
                spheres[0].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
        }
        spheres[0].setVelocity(4 * cos(Angle), 4 * sin(Angle), 0.0f);
    }
    else if (spheres.size() == 3) {
        switch (key) {
        case GLUT_KEY_UP:
            if ((int)a % 360 < 270 && (int)a % 360 > 90) {
                Angle -= AngVel;
                spheres[1].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
            else {
                Angle += AngVel;
                spheres[1].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
        case GLUT_KEY_DOWN:
            if ((int)a % 360 < 270 && (int)a % 360 > 90) {
                Angle += AngVel;
                spheres[1].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
            else {
                Angle -= AngVel;
                spheres[1].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
        case GLUT_KEY_LEFT:
            if ((int)a % 360 < 180 && (int)a % 360 > 0) {
                if (a < 0)
                    Angle -= AngVel;
                else
                    Angle += AngVel;
                spheres[1].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
            else {
                if (a < 0)
                    Angle += AngVel;
                else
                    Angle -= AngVel;
                spheres[1].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
        case GLUT_KEY_RIGHT:

            if ((int)a % 360 < 180 && (int)a % 360 > 0) {
                if (a < 0)
                    Angle += AngVel;
                else
                    Angle -= AngVel;
                spheres[1].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
            else {
                if (a < 0)
                    Angle -= AngVel;
                else
                    Angle += AngVel;
                spheres[1].setCenter(80 * cos(Angle) - 160, 80 * sin(Angle), 0);
                break;
            }
        }
        spheres[1].setVelocity(4 * cos(Angle), 4 * sin(Angle), 0.0f);
    }

}

int main(int argc, char** argv) {
    // init GLUT and create Window
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowPosition(WINDOW_X, WINDOW_Y);
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
    glutCreateWindow("PM Project PuzzLoop");
    initialize();

    // register callbacks

    glutDisplayFunc(display);

    glutKeyboardFunc(keyboardDown);
    glutSpecialFunc(specialKeyDown);
    glutIdleFunc(idle);

    // enter GLUT event processing cycle
    glutMainLoop();

    return 0;
}