#pragma once
#include<iostream>
#include<GL/glut.h>
#include<FreeImage.h>

using namespace std;

class Texture {
public:
	FIBITMAP* createBitMap(char const* filename);
	void generateTexture();
	void drawSquareWithTextureStage();
	void drawSquareWithTextureStage2();
	void drawSquareWithTexture();
	void displayCharacters(void* font, string str, float x, float y);

	GLuint textureID;
	GLubyte* textureData;
	int imageWidth, imageHeight;
};
